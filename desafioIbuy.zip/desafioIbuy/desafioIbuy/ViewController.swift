//
//  ViewController.swift
//  desafioIbuy
//
//  Created by Rodrigo Leme on 30/10/20.
//  Copyright © 2020 Rodrigo Leme. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //MARK: - Outlets
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableViewList: UITableView!
    
    
    //MARK: - Actions
    
    @IBAction func actionButtonAdd(_ sender: Any) {
        modifyItems(section: nil, row: nil)
    }
    
    //MARK: - Attributs
    private var item = [[Item](),[Item]()]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //item.append(Item(name: "Maçã", isOpen: true)),item.append(Item(name: "Maçã", isOpen: true))
        //item.append([Item(name: "Maçã", isOpen: true)])
        
        item[0].append(Item(name: "Maçã", isOpen: true))
        item[0].append(Item(name: "Uva", isOpen: true))
        item[1].append(Item(name: "Banana", isOpen: false))
        item[1].append(Item(name: "Melão", isOpen: false))
        
        tableViewList.delegate = self
        tableViewList.dataSource = self
        
        //readArray()
    }

    //função alert inserir ou editar
    func modifyItems(section: Int?, row: Int?)  {
     var title = "Inserir Item"
     var nomeItem = ""
    
        if let secao = section, let row = row {
            title = "Alterar Item"
            nomeItem = item[secao][row].name
            
        }
        
        let alertText = UIAlertController(title: title, message: "Digite um item", preferredStyle: .alert)
        alertText.addTextField { (textField) in
            if nomeItem == "" {
          textField.placeholder = "Ex: Maçã"
            } else {
          textField.text = nomeItem
            }
        }
        
        alertText.addAction(UIAlertAction(title: "Salvar", style: .default, handler: { (acao) in
            let textField = alertText.textFields![0] as UITextField
            if let ntext = textField.text {
                

                self.insertItem(name: ntext, section: section, row: row)
 
                
            }
        }))
        alertText.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: nil))
        present(alertText, animated: true, completion: nil)
        
    }
    
    func insertItem(name: String, section: Int?, row: Int?) {
        if let section = section, let row = row {
            item[section][row].name = name
        } else {
            item[0].append(Item(name: name, isOpen: true))
        }
        tableViewList.reloadData()
    }
    
    func changeOption(section: Int, row: Int) {
        item[section][row].isOpen = !item[section][row].isOpen
        reloadArray()
        tableViewList.reloadData()
    }
    
    func reloadArray() {
        var arrayOpen = [Item]()
        var arrayClose = [Item]()
        
        for item in item[0] {
            if item.isOpen {
                arrayOpen.append(item)
            } else {
                arrayClose.append(item)
            }
        }
        
        for item in item[1] {
            if item.isOpen {
                arrayOpen.append(item)
            } else {
                arrayClose.append(item)
            }
        }
        
        self.item[0].removeAll()
        self.item[1].removeAll()
        
        for item in arrayOpen {
            self.item[0].append(item)
        }
        
        for item in arrayClose {
            self.item[1].append(item)
        }
    }
    
    func deleteItem(section: Int, row: Int) {
        item[section].remove(at: row)
        tableViewList.reloadData()
    }
    
}





//MARK: - TableViewDelegate, TableViewDataSource
extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return item[section].count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        //cell.textLabel?.text = item[indexPath.section][indexPath.row].name
        cell.textLabel?.text = item[indexPath.section][indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 {
            return "Abertos"
        }
        return "Concluídos"
    }
    
//    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
//
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alertSheet = UIAlertController(title: "", message: "Selecione a opção desejada", preferredStyle: .actionSheet)
        
        if indexPath.section == 0 {
            alertSheet.addAction(UIAlertAction(title: "Marcar como concluído", style: .default, handler: { (action) in
                self.changeOption(section: indexPath.section, row: indexPath.row)
            }))
            
            alertSheet.addAction(UIAlertAction(title: "Editar", style: .default, handler: { (action) in
                self.modifyItems(section: indexPath.section, row: indexPath.row)
            }))
        } else {
            alertSheet.addAction(UIAlertAction(title: "Desmarcar como concluído", style: .default, handler: { (action) in
              self.changeOption(section: indexPath.section, row: indexPath.row)
            }))
        }
        
        alertSheet.addAction(UIAlertAction(title: "Excluir", style: .destructive, handler: { (action) in
            self.deleteItem(section: indexPath.section, row: indexPath.row)
        }))
        alertSheet.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: { (action) in
          
        }))
        present(alertSheet, animated: true, completion: nil)
    }
    
}

