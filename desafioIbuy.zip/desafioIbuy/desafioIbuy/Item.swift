//
//  Item.swift
//  desafioIbuy
//
//  Created by Rodrigo Leme on 30/10/20.
//  Copyright © 2020 Rodrigo Leme. All rights reserved.
//

import Foundation

class Item {
    var name: String
    var isOpen: Bool
    
    init(name: String, isOpen: Bool) {
        self.name = name
        self.isOpen = isOpen
    }
}
