//
//  ItemsOpen.swift
//  desafioIbuy
//
//  Created by Rodrigo Leme on 30/10/20.
//  Copyright © 2020 Rodrigo Leme. All rights reserved.
//

import Foundation

class ItemsOpen {
    
}
